class DtoConstants {
  static final String userDtoUsername = 'username';
  static final String userDtoPassword = 'password';

  static final String userDtoId = 'id';
  static final String userDtoEmail = 'email';
  static final String userDtoFirstName = 'firstName';
  static final String userDtoLastName = 'lastName';
  static final String userDtoToken = 'token';
}
