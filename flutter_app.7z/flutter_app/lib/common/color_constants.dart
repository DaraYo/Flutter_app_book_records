import 'dart:ui';

class ColorConstants {
  static const Color color1 = Color.fromARGB(255, 217, 50, 94);
  static const Color color2 = Color.fromARGB(255, 153, 200, 242);
  static const Color color3 = Color.fromARGB(255, 242, 130, 65);
  static const Color color4 = Color.fromARGB(255, 217, 67, 67);
  static const Color color5 = Color.fromARGB(255, 242, 242, 242);
}
