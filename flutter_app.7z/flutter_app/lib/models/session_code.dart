class SessionCode {
  int sessionId;
  String code;
  bool deleted;
}
