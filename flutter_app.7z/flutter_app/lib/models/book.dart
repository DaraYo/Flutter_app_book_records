class Book {
  String code;
  String title;
  String author1;
  String author2;
  String author3;
  String author4;
  String author5;
  String publishedDate;
  int pageCount;
  String language;
  bool deleted;
}
